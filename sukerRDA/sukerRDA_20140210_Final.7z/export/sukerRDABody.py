# -*- coding: utf-8 -*-
"""
Created on Thu Feb 06 14:24:34 2014

@author: choonghyun.jeon
"""
import string
import mmap
from sukerRDAHH import getDirMark

class abstractorBody():
    DEBUG_ON = True
    
    crashTypeTitle = "Crash Type Select"
    crashTypeList = ["Search All", \
                     "Kernel Crash(Black)", \
                     "Apps Watchdog(Green)", \
                     "DBI Crash(Purple)", \
                     "RPM Crash(Yellow)", \
                     "Modem Crash(Blue)", \
                     "ADSP Crash(Orange)", \
                     "WCNSS Crash(Sky)"]
    crashTypeIdx = 0

    check_buildIdList = ["BOOT.BF","TZ.BF","RPM.BF"]
    parsingListInLK = ["androidboot.hardware", "lge.rev", "lge.bootreason"]
    parsingListInKernel = ["Linux version","UART CONSOLE :","BOARD :","ANDROID BOOT MODE :","Battery :"]   
    
    check_lk_log_mark = "[0] welcome to lk"    
    
    check_kernel_log_START_mark = "Booting Linux on physical CPU 0"
    check_kernel_log_END_mark = "" #not used
    """
    crashType_Black_keywordL = ["] PC is at ", "] Causing a watchdog bite!"]  #kernel crash normal and kernel crash by watchdog bite
    crashType_Green_keyword = "] pet_watchdog"
    crashType_Purple_keyword = "] pet_watchdog"
    crashType_Yellow_keyword = ""
    crashType_Blue_keywordL = ["] Fatal error on the modem.", "] Watchdog bite received from modem software!"]
    crashType_Orange_keyword = "] Fatal error on the ADSP!"
    crashType_Sky_keyword = "] Fatal error on the wcnss."
    
    crashTypeHash = {crashTypeList[1]:crashType_Black_keywordL, \
                     crashTypeList[2]:crashType_Green_keyword, \
                     crashTypeList[3]:crashType_Purple_keyword, \
                     crashTypeList[4]:crashType_Yellow_keyword, \
                     crashTypeList[5]:crashType_Blue_keywordL, \
                     crashTypeList[6]:crashType_Orange_keyword, \
                     crashTypeList[7]:crashType_Sky_keyword}

    crashType_All_keyword = [crashType_Black_keyword, crashType_Green_keyword, crashType_Purple_keyword, crashType_Yellow_keyword,
                            crashType_Blue_keyword, crashType_Orange_keyword, crashType_Sky_keyword]
    """
    crashType_Black_keywordL = ["] PC is at ", "] Causing a watchdog bite!"]  #kernel crash normal and kernel crash by watchdog bite   
    crashType_Green_keyword = "] pet_watchdog"
    crashType_Purple_keyword = "] pet_watchdog"
    crashType_Blue_keywordL = ["] Fatal error on the modem.", "] Watchdog bite received from modem software!"]
    crashType_Orange_keyword = "] Fatal error on the ADSP!"
    crashType_Sky_keyword = "] Fatal error on the wcnss."
    
    crashTypeHash = {crashTypeList[1]:crashType_Black_keywordL, \
                     crashTypeList[2]:crashType_Green_keyword, \
                     crashTypeList[3]:crashType_Purple_keyword, \
                     crashTypeList[5]:crashType_Blue_keywordL, \
                     crashTypeList[6]:crashType_Orange_keyword, \
                     crashTypeList[7]:crashType_Sky_keyword}

    crashType_All_keyword1 = [i for i in crashType_Black_keywordL]
    crashType_All_keyword2 = [i for i in crashType_Blue_keywordL]    
    crashType_All_keyword3 = [crashType_Green_keyword, crashType_Purple_keyword, crashType_Orange_keyword, crashType_Sky_keyword]
    crashType_All_keywordsL = crashType_All_keyword1 + crashType_All_keyword2 + crashType_All_keyword3
    
    BIN_0 = "DDRCS0.BIN"
    BIN_1 = "DDRCS1.BIN"
    
    PARSE_STEP1 = 1
    PARSE_STEP1 = 2
    
    KERNEL_CATCH_SIZE = 1024*512  #512KB
    DEFAULT_CATCH_SIZE = 1024*256  #256KB
    LK_LOG_SIZE = 16*1024  #16KB

    #--------------------------------------- for summingup ---------------------------------------
    lkLogFileName = ""
    kernelLogFileName = ""
    crashlLogFileName = ""
    etcFileName = ""
    
    #--------------------------------------- for parsing ---------------------------------------
    lk_log = ""
    kernel_log = ""
    crash_log = ""
    etc_log = ""
            
    def __init__(self):
        pass
    
    def logSummingUp(self, logoutCls, dirPath) :
        if len(self.lkLogFileName)<1 or len(self.kernelLogFileName)<1 :
            self.lkLogFileName = dirPath+"\lk_log.txt"
            self.kernelLogFileName = dirPath+"\kernel_log.txt"
            self.etcFileName = dirPath+"\etc_log.txt"
            
        
        lkListTemp = []
        kernelListTemp = []
        etcListTemp = []
        
        #--------------lk-----------------
        try :
            with open(self.lkLogFileName) as data :
                for line in data :
                    for getLK in self.parsingListInLK :
                        if getLK in line and line in lkListTemp :
                            temp = []
                            temp = line.split(' ')
                            for tempGet in temp :
                                if getLK in tempGet and tempGet not in lkListTemp:
                                    lkListTemp.append(tempGet)
                                    lkListTemp.append("\n")
        except IOError :
            print "File open error"
            
        for s in lkListTemp :
            logoutCls.lkWriteOuts(s)
        
        #--------------kernel-----------------
        try :
            with open(self.kernelLogFileName) as data :
                for line in data :
                    for getKernel in self.parsingListInKernel :
                        if getKernel in line :
                            indexx = string.find(line, getKernel)
                            temp = line[indexx:].strip()
                            if temp not in kernelListTemp :
                                kernelListTemp.append(line[indexx:].strip())
                                kernelListTemp.append("\n")
        except IOError :
            print "File open error"

        for s in kernelListTemp :
            logoutCls.kernelWriteOuts(s)            

        #--------------etc-----------------
        try :
            with open(self.etcFileName) as data :
                for line in data :
                    for getEtc in self.check_buildIdList :
                        if getEtc in line and getEtc not in etcListTemp :
                            indexx = string.find(line, getEtc)
                            etcListTemp.append(line[indexx:].strip())
                            etcListTemp.append("\n")                
        except IOError :
            print "File open error" 

        for s in etcListTemp :
            logoutCls.etcWriteOuts(s)        

    def logParsing(self, dirPath, binFileName, acceptEtc=True, step=1, loggingSize=256) :
        self.lkLogFileName = dirPath+"\lk_log.txt"
        self.kernelLogFileName = dirPath+"\kernel_log.txt"
        self.crashlLogFileName = dirPath+"\crash_log.txt"
        self.etcFileName = dirPath+"\etc_log.txt"

        if loggingSize == 0 or loggingSize < 256 :
            getLogSize = self.DEFAULT_CATCH_SIZE
        else :
            getLogSize = loggingSize*1024
            
        start_KERNEL_LOG_PosL = []
        end_KERNEL_LOG_PosL = []
        
        start_CRASH_PosL = []
        end_CRASH_PosL = []        

        start_LK_PosL = []
        end_LK_PosL = []
        
        self.lk_log = file(self.lkLogFileName, 'w')
        self.kernel_log = file(self.kernelLogFileName, 'w')
        self.crash_log = file(self.crashlLogFileName, 'w')
        
        if acceptEtc==True :
            self.etc_log = file(self.etcFileName, 'w')

        lk_logging_done = False
        kernel_logging_done = False
        panic_logging_done = False
        #buildId_logging_done = False
                
        with open(dirPath + getDirMark() + binFileName, 'rb') as ddrcs_bin:
            m = mmap.mmap(ddrcs_bin.fileno(), 0,access=mmap.ACCESS_READ)
            currPos = 0
            if step==2 :
                ddrcs_bin.seek(268435456)  #256MB
                
            #-----------------------------------------------------------
            #       CRASH LOG PARSING
            #-----------------------------------------------------------
            if not self.crashTypeIdx==0 :
                if isinstance(self.crashTypeHash[self.crashTypeList[self.crashTypeIdx]], list) :                    
                    for ele in self.crashTypeHash[self.crashTypeList[self.crashTypeIdx]] :
                        if self.DEBUG_ON :
                            print "Crash log step : not select all --->\n"
                            print "    Crash type : " + self.crashTypeHash[self.crashTypeList[self.crashTypeIdx]] + "\n"
                            print "    ele = " + ele + "\n"                            
                        m.seek(0)
                        panic_logging_done = False
                        ret = self.doParsingCrash(panic_logging_done, m, ele, start_CRASH_PosL, end_CRASH_PosL, False, getLogSize)
                        if self.DEBUG_ON :                           
                            print "    ret = " + ret
                else :            
                    ret = self.doParsingCrash(panic_logging_done, m, \
                                              self.crashTypeHash[self.crashTypeList[self.crashTypeIdx]], \
                                              start_CRASH_PosL, end_CRASH_PosL, False, getLogSize)
            else :  #search all
                for ele in self.crashType_All_keywordsL :
                    m.seek(0)
                    panic_logging_done = False
                    ret = self.doParsingCrash(panic_logging_done, m, ele, start_CRASH_PosL, end_CRASH_PosL, True, getLogSize)
                    if self.DEBUG_ON :
                        print "Crash log step : select all --->\n"
                    if ret==1 :
                        break
            
            m.seek(0)
            
            #-----------------------------------------------------------
            #       KERNEL LOG PARSING
            #-----------------------------------------------------------
            while kernel_logging_done==False :
                currPos = m.find(self.check_kernel_log_START_mark)
                if not currPos==-1 :
                    start_KERNEL_LOG_PosL.append(currPos)
                    end_KERNEL_LOG_PosL.append(currPos+self.KERNEL_CATCH_SIZE)
                    m.seek(currPos+1)
                else :
                    kernel_logging_done = True            
            m.seek(0)

            #-----------------------------------------------------------
            #       LK LOG PARSING
            #-----------------------------------------------------------
            while lk_logging_done==False :
                currPos = m.find(self.check_lk_log_mark)
                if not currPos==-1 :
                    start_LK_PosL.append(currPos)
                    end_LK_PosL.append(currPos+self.LK_LOG_SIZE)    
                    m.seek(currPos+1)
                else :
                    lk_logging_done = True
            m.seek(0)
          
            #-----------------------------------------------------------
            #       ETC LOG PARSING
            #-----------------------------------------------------------          
            if acceptEtc==True :
                for checkOther in self.check_buildIdList :
                    currPos = m.find(checkOther)
                    if not currPos==-1 :
                        m.seek(currPos)
                        tempOtherStr = m.read(1024)
                        break
                
                if len(tempOtherStr) > 0 :
                    l_tempList = tempOtherStr.strip().split(chr(0))
                    tempList = set(l_tempList)
                    #print len(tempList)
                    for t in tempList :
                        for s in self.check_buildIdList :
                            if s in t :
                                indexy = string.find(t, s)
                                tempList2 = t[indexy:].strip().split(chr(0)) 
                                        
                                self.etc_log.write(tempList2[0])
                                self.etc_log.write("\n")

            m.seek(0)
            self.crash_log.write("\n-------------------------------------------------- Crash Log Start ------------------------------------------------------\n")
            for i in range(len(start_CRASH_PosL)) :
                m.seek(start_CRASH_PosL[i])                
                self.crash_log.write(m.read(end_CRASH_PosL[i]-start_CRASH_PosL[i]))
            self.crash_log.write("\n--------------------------------------------------- Crash Log End -------------------------------------------------------\n")

            self.kernel_log.write("\n------------------------------------------------- Kernel Log Start -----------------------------------------------------\n")
            for i in range(len(start_KERNEL_LOG_PosL)) :
                m.seek(start_KERNEL_LOG_PosL[i])
                self.kernel_log.write(m.read(end_KERNEL_LOG_PosL[i]-start_KERNEL_LOG_PosL[i])+"\n")
            self.kernel_log.write("\n---------------------------------------------------- Kernel Log End ----------------------------------------------------\n")
            
            self.lk_log.write("\n------------------------------------------------------ LK Log Start ------------------------------------------------------\n")
            for i in range(len(start_LK_PosL)) :
                m.seek(start_LK_PosL[i])        
                self.lk_log.write(m.read(end_LK_PosL[i]-start_LK_PosL[i])+"\n")
            self.lk_log.write("\n--------------------------------------------------------- LK Log End -----------------------------------------------------\n")
            
            self.fileHandleClose(acceptEtc)
            m.close()
            ddrcs_bin.close()

    def doParsingCrash(self, panic_logging_done, m, ele, start_CRASH_PosL, end_CRASH_PosL, isSearchAll=False, getLogSize=2662144) :
        while panic_logging_done==False :
            currPos = m.find(ele)
            if currPos==-1 :
                panic_logging_done = True
            else :
                m.seek(currPos)
                read1Line = m.read(256)     
                if "%s" not in read1Line :
                    start_CRASH_PosL.append(currPos-getLogSize/2)
                    end_CRASH_PosL.append(currPos+getLogSize/2)                    
                    panic_logging_done = True
                    if isSearchAll==True :
                        if self.DEBUG_ON :
                            print "    catch log a line : " + read1Line + "\n"
                            print "    and return 1 \n"
                        return 1
        return 0
            
    def checkOutFiles(self, __os) :
        if __os.path.getsize(self.kernelLogFileName)==0 : #__os.path.getsize(self.lkLogFileName)==0 or 
            return 0
        else :
            return 1

    def fileHandleClose(self, acceptEtc) :
        self.lk_log.close()
        self.kernel_log.close()
        self.crash_log.close()
        if acceptEtc==True :
            self.etc_log.close() 