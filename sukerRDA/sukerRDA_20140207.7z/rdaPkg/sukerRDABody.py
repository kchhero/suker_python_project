# -*- coding: utf-8 -*-
"""
Created on Thu Feb 06 14:24:34 2014

@author: choonghyun.jeon
"""
import string
import mmap
from sukerRDAHH import getDirMark

class abstractorBody():
    crashTypeTitle = "Crash Type Select"
    crashTypeList = ["Search All", \
                     "Kernel Cras(Black)", \
                     "Apps Watchdog(Green)", \
                     "DBI Crash(Purple)", \
                     "RPM Crash(Yellow)", \
                     "Modem Crash(Blue)", \
                     "ADSP Crash(Orange)", \
                     "WCNSS Crash(Sky)"]
    crashTypeIdx = 0

    check_buildIdList = ["BOOT.BF","TZ.BF","RPM.BF"]
    parsingListInLK = ["androidboot.hardware", "lge.rev", "lge.bootreason"]
    parsingListInKernel = ["Linux version","UART CONSOLE :","BOARD :","ANDROID BOOT MODE :","Battery :"]   
    
    check_lk_log_mark = "[0] welcome to lk"    
    
    check_kernel_log_START_mark = "Booting Linux on physical CPU 0"
    check_kernel_log_END_mark = "" #not used
    """
    crashType_Black_keyword = "PC is at"
    crashType_Green_keyword = ""
    crashType_Purple_keyword = ""
    crashType_Yellow_keyword = ""
    crashType_Blue_keyword = ""
    crashType_Orange_keyword = "Fatal error on the ADSP!"
    crashType_Sky_keyword = ""
    
    crashTypeHash = {crashTypeList[1]:crashType_Black_keyword, \
                     crashTypeList[2]:crashType_Green_keyword, \
                     crashTypeList[3]:crashType_Purple_keyword, \
                     crashTypeList[4]:crashType_Yellow_keyword, \
                     crashTypeList[5]:crashType_Blue_keyword, \
                     crashTypeList[6]:crashType_Orange_keyword, \
                     crashTypeList[7]:crashType_Sky_keyword}

    crashType_All_keyword = [crashType_Black_keyword, crashType_Green_keyword, crashType_Purple_keyword, crashType_Yellow_keyword,
                            crashType_Blue_keyword, crashType_Orange_keyword, crashType_Sky_keyword]
    """
    crashType_Black_keyword = "PC is at"    
    crashType_Orange_keyword = "Fatal error on the ADSP!"
    
    crashTypeHash = {crashTypeList[1]:crashType_Black_keyword, \
                     crashTypeList[6]:crashType_Orange_keyword}

    crashType_All_keyword = [crashType_Black_keyword,crashType_Orange_keyword]
    # "Causing a watchdog bite!"
    
    lkLogFileName = ""
    kernelLogFileName = ""    
    etcFileName = ""
    
    BIN_0 = "DDRCS0.BIN"
    BIN_1 = "DDRCS1.BIN"
    
    PARSE_STEP1 = 1
    PARSE_STEP1 = 2
    
    #kernel_log_max_size = 1024*1024  #1MB
    GET_WANT_CATCH_SIZE = 1024*256  #256K
    LK_LOG_SIZE = 8*1024  #8KB
        
    def __init__(self):
        pass
    
    def logSummingUp(self, logoutCls, dirPath) :
        if len(self.lkLogFileName)<1 or len(self.kernelLogFileName)<1 :
            self.lkLogFileName = dirPath+"\lk_log.txt"
            self.kernelLogFileName = dirPath+"\kernel_log.txt"
            self.etcFileName = dirPath+"\etc_log.txt"
            
        
        lkListTemp = []
        kernelListTemp = []
        etcListTemp = []
        
        #--------------lk-----------------
        try :
            with open(self.lkLogFileName) as data :
                for line in data :
                    for getLK in self.parsingListInLK :
                        if getLK in line and line in lkListTemp :
                            temp = []
                            temp = line.split(' ')
                            for tempGet in temp :
                                if getLK in tempGet and tempGet not in lkListTemp:
                                    lkListTemp.append(tempGet)
                                    lkListTemp.append("\n")
        except IOError :
            print "File open error"
            
        for s in lkListTemp :
            logoutCls.lkWriteOuts(s)
        
        #--------------kernel-----------------
        try :
            with open(self.kernelLogFileName) as data :
                for line in data :
                    for getKernel in self.parsingListInKernel :
                        if getKernel in line :
                            indexx = string.find(line, getKernel)
                            temp = line[indexx:].strip()
                            if temp not in kernelListTemp :
                                kernelListTemp.append(line[indexx:].strip())
                                kernelListTemp.append("\n")
        except IOError :
            print "File open error"

        for s in kernelListTemp :
            logoutCls.kernelWriteOuts(s)            

        #--------------etc-----------------
        try :
            with open(self.etcFileName) as data :
                for line in data :
                    for getEtc in self.check_buildIdList :
                        if getEtc in line and getEtc not in etcListTemp :
                            indexx = string.find(line, getEtc)
                            etcListTemp.append(line[indexx:].strip())
                            etcListTemp.append("\n")                
        except IOError :
            print "File open error" 

        for s in etcListTemp :
            logoutCls.etcWriteOuts(s)        

    def logParsing(self, dirPath, binFileName, acceptEtc=True, step=1) :
        self.lkLogFileName = dirPath+"\lk_log.txt"
        self.kernelLogFileName = dirPath+"\kernel_log.txt"
        self.etcFileName = dirPath+"\etc_log.txt"

        start_KERNEL_LOG_PosL = []
        end_KERNEL_LOG_PosL = []
        
        start_CRASH_PosL = []
        end_CRASH_PosL = []        

        start_LK_PosL = []
        end_LK_PosL = []
        
        lk_log = file(self.lkLogFileName, 'w')
        kernel_log = file(self.kernelLogFileName, 'w')
        if acceptEtc==True :
            etc_log = file(self.etcFileName, 'w')

        lk_logging_done = False
        kernel_logging_done = False
        panic_logging_done = False
        #buildId_logging_done = False
                
        with open(dirPath + getDirMark() + binFileName, 'rb') as ddrcs_bin:
            m = mmap.mmap(ddrcs_bin.fileno(), 0,access=mmap.ACCESS_READ)
            currPos = 0
            if step==2 :
                ddrcs_bin.seek(268435456)  #256MB
            
            #-----------------------------------------------------------
            #       KERNEL LOG PARSING
            #-----------------------------------------------------------
            while kernel_logging_done==False :
                currPos = m.find(self.check_kernel_log_START_mark)
                if not currPos==-1 :
                    start_KERNEL_LOG_PosL.append(currPos)
                    end_KERNEL_LOG_PosL.append(currPos+self.GET_WANT_CATCH_SIZE*2)
                    m.seek(currPos+1)
                else :
                    kernel_logging_done = True            
            m.seek(0)

            #-----------------------------------------------------------
            #       CRASH LOG PARSING
            #-----------------------------------------------------------
            if not self.crashTypeIdx==0 :
                while panic_logging_done==False :
                    currPos = m.find(self.crashTypeHash[self.crashTypeList[self.crashTypeIdx]])
                    if currPos==-1 :
                        panic_logging_done = True
                    else :
                        m.seek(currPos)
                        read1Line = m.read(256)     
                        #print read1Line
                        if "%s" not in read1Line :
                            start_CRASH_PosL.append(currPos-self.GET_WANT_CATCH_SIZE)
                            end_CRASH_PosL.append(currPos+self.GET_WANT_CATCH_SIZE)
                            panic_logging_done = True
            else :  #search all
                for i in self.crashType_All_keyword :
                    panic_logging_done = False
                    while panic_logging_done==False :
                        currPos = m.find(i)
                        if currPos==-1 :
                            panic_logging_done = True
                        else :
                            m.seek(currPos)
                            read1Line = m.read(256)     
                            #print read1Line
                            if "%s" not in read1Line :
                                start_CRASH_PosL.append(currPos-self.GET_WANT_CATCH_SIZE)
                                end_CRASH_PosL.append(currPos+self.GET_WANT_CATCH_SIZE)
                                panic_logging_done = True
            
            m.seek(0)
            
            #-----------------------------------------------------------
            #       LK LOG PARSING
            #-----------------------------------------------------------
            while lk_logging_done==False :
                currPos = m.find(self.check_lk_log_mark)
                if not currPos==-1 :
                    start_LK_PosL.append(currPos)
                    end_LK_PosL.append(currPos+self.LK_LOG_SIZE)    
                    m.seek(currPos+1)
                else :
                    lk_logging_done = True
            m.seek(0)
          
            #-----------------------------------------------------------
            #       ETC LOG PARSING
            #-----------------------------------------------------------          
            if acceptEtc==True :
                for checkOther in self.check_buildIdList :
                    currPos = m.find(checkOther)
                    if not currPos==-1 :
                        m.seek(currPos)
                        tempOtherStr = m.read(1024)
                        break
                
                l_tempList = tempOtherStr.strip().split(chr(0))
                tempList = set(l_tempList)
                #print len(tempList)
                for t in tempList :
                    for s in self.check_buildIdList :
                        if s in t :
                            indexy = string.find(t, s)
                            tempList2 = t[indexy:].strip().split(chr(0)) 
                                    
                            etc_log.write(tempList2[0])
                            etc_log.write("\n")                            
        
            if acceptEtc==True :
                etc_log.close()            

            m.seek(0)
            kernel_log.write("\n------------------------ Crash Log ------------------------\n")
            for i in range(len(start_CRASH_PosL)) :
                m.seek(start_CRASH_PosL[i])                
                kernel_log.write(m.read(end_CRASH_PosL[i]-start_CRASH_PosL[i]))
                kernel_log.write("--------------------------------------------------------------\n")
                kernel_log.write("--------------------------------------------------------------\n")
            
            kernel_log.write("\n------------------------ Kernel Log ------------------------\n")
            for i in range(len(start_KERNEL_LOG_PosL)) :
                m.seek(start_KERNEL_LOG_PosL[i])
                kernel_log.write(m.read(end_KERNEL_LOG_PosL[i]-start_KERNEL_LOG_PosL[i])+"\n")
                kernel_log.write("--------------------------------------------------------------\n")
                kernel_log.write("--------------------------------------------------------------\n")                
            kernel_log.close()
            
            lk_log.write("\n------------------------ LK Log ------------------------\n")
            for i in range(len(start_LK_PosL)) :
                m.seek(start_LK_PosL[i])        
                lk_log.write(m.read(end_LK_PosL[i]-start_LK_PosL[i])+"\n")
                lk_log.write("******************************************************************\n")
                lk_log.write("******************************************************************\n")
            lk_log.close()
            
            m.close()
            ddrcs_bin.close()

    def checkOutFiles(self, __os) :
        if __os.path.getsize(self.kernelLogFileName)==0 : #__os.path.getsize(self.lkLogFileName)==0 or 
            return 0
        else :
            return 1
