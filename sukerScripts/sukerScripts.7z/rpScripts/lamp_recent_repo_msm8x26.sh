#! /bin/bash

repolr -b lamp_l_release -m msm8x26/msm8x26-recent.xml
repo sync -cq -d -j4 --no-tags
repo start lamp_l_release --all
repo forall -c 'git remote set-url --push lr ssh://lr.lge.com:029475/${REPO_PROJECT}'

