#! /bin/bash

repo sync -cq -d -j4 --no-tags
repo start lamp_l_release --all
