#! /bin/bash

repolr -b msm8x26_l_w7_tmo_us_mp_150217
repo sync -cq -j4
repo start msm8x26_l_w7_tmo_us_mp_150217 --all
