#! /bin/bash

repolr -b lamp_l_mr1_release -m msm8916/msm8916.xml
repo sync -cq -d -j4 --no-tags
repo start lamp_l_mr1_release --all
