#! /bin/bash

git config core.whitespace tab-in-indent
git show --check
