cd android

cd bootable
~/mkcscope.sh; cd ..

cd kernel
~/mkcscope.sh; cd ..

cd system
~/mkcscope.sh; cd ..

cd vendor/lge/demigod_proprietary
~/mkcscope.sh; cd ..

cd ..
cd non_HLOS

cd boot_images
~/mkcscope.sh; cd ..
