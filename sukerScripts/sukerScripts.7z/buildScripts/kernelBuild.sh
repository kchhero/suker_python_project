#! /bin/sh
echo 'ONE_SHOT_MAKEFILE=build/target/board/Android.mk m bootimage'
