#line20str = [0]*20
#line20int = [0]*20
lineL = [0]*15
index=0
sum = 0

#array save
try :
    with open("my_problem_18_text.txt") as data :
        for line in data :
            lineL[index] = line.strip().split(' ')
            index = index+1
except IOError :
    print "File open error"

#print lineL

beforIndex = 0
sum += int(lineL[14][0])

for i in range(13,-1,-1) :
    sum += int(lineL[i][beforIndex])
        else :
            sum += int(lineL[i][beforIndex+1])
    print sum
    
print sum
"""
