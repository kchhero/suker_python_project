def num3(n) :
    return n*(n+1)/2
def num4(n) :
    return n*n
def num5(n) :
    return n*(3*n-1)/2
def num6(n) :
    return n*(2*n-1)
def num7(n) :
    return n*(5*n-3)/2
def num8(n) :
    return n*(3*n-2)

num3L = []
num4L = []
num5L = []
num6L = []
num7L = []
num8L = []

for i in range(10,200) :
    temp = num3(i)
    if temp >= 1000 and temp <= 9999 :
        num3L.append(str(temp))

    temp = num4(i)
    if temp >= 1000 and temp <= 9999 :
        num4L.append(str(temp))

    temp = num5(i)
    if temp >= 1000 and temp <= 9999 :
        num5L.append(str(temp))

    temp = num6(i)
    if temp >= 1000 and temp <= 9999 :
        num6L.append(str(temp))

    temp = num7(i)
    if temp >= 1000 and temp <= 9999 :
        num7L.append(str(temp))

    temp = num8(i)
    if temp >= 1000 and temp <= 9999 :
        num8L.append(str(temp))

ttL = num3L+num4L+num5L+num6L+num7L+num8L
print "ttL make done!"
print num8L
print num7L
ttL = []
answerCnt=6
#dddL = [num3L,num4L,num5L,num6L,num7L,num8L]
"""
dddL = ["1","2","3","4","5","6"]

for a in range(6) :
    ttL = []
    ttL += dddL[a]
    for b in range(5) :
        ttL += dddL[b]
        for c in range(4) :
            ttL += dddL[c]
            for d in range(3) :
                ttL += dddL[d]
                ttL.pop()
                for e in range(2) :
                    ttL += dddL[e]                    
                    for f in range(1) :
                        ttL += dddL[f]
                        print ttL

                        
    """
for i in range(len(ttL)) :
    baseNum = ttL[i]
    checkBNum = baseNum[2]+baseNum[3]    
    circularL = []
    while 1 :
        circularL.append(baseNum)
        for nn in ttL :
            tempStr = nn
            compareNum = tempStr[0]+tempStr[1]
            if checkBNum==compareNum :
                circularL.append(tempStr)                            
                isGoing = 1
                checkBNum = tempStr[2]+tempStr[3]

        ccLen = len(circularL)        
        if answerCnt==ccLen :
            print circularL
            atatStr = circularL[0]
            tataStr = circularL[ccLen-1]
            if atatStr[0]+atatStr[1]==tataStr[2]+tataStr[3] :
                print circularL
                
            delCnt = 0
            isExistCircular = circularL[0]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)
                    delCnt += 1
                    break
            isExistCircular = circularL[1]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)                    
                    delCnt += 1
                    break
            isExistCircular = circularL[2]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)                    
                    delCnt += 1
                    break                
            isExistCircular = circularL[3]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)                    
                    delCnt += 1
                    break
            isExistCircular = circularL[4]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)                    
                    delCnt += 1
                    break
            isExistCircular = circularL[5]
            for mm in range(len(dddL)) :
                if isExistCircular in dddL[mm] :
                    dddL.pop(mm)                    
                    delCnt += 1
                    break
                
            if delCnt==6 :
                print "Answer :",circularL
                sys.exit()
            break
        else :
            break
        
print "END---"









