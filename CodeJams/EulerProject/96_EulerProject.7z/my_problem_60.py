import math

def suker_isPrimeNum(n) :
    if n==2 or n==3 or n==5 or n==7 :
        return 1
    elif n%2==0 :
        return 0
    else :
        sqrtNum = int(math.sqrt(n))
        for i in range(3,sqrtNum+1) :
            if n%i==0 :
                return 0

        return 1
    
primeL = [i for i in range(3,999) if suker_isPrimeNum(i)==1]

print len(primeL)
"""
prime5L
for f1 in range(len(prime5L)-1) :
    for f2 in range(len(prime5L)-2) :
        #check1
        tempStr = str(prime5L[f1])+str(prime5L[f2])
        tempInt = int(tempStr)
        if suker_PrimeNum(tempInt)==1 :
            #check2
            tempReverseStr = str(prime5L[f2])+str(prime5L[f1])
            tempInt = int(tempReverseStr)
            if suker_PrimeNum(tempInt)==1 :
   """         