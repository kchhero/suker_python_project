import math

def isPrime(n) :
    if n==3 or n==5 or n==7 :
        return 1
    elif n%2==0 or n==1 :
        return 0
    else :
        temp = int(math.sqrt(n))
        for i in range(3,temp+1,2) :
            if n%i==0 :
                return 0

        return 1
        
crossL = []
n = 1
acc = 2
primeCrossNum = 0    
totalCrossNum = 1

for squareNum in range(1,60000) :
    if squareNum==1 :
        crossL.append(n)
    else :
        for i in range(4) :
            n += acc
            crossL.append(n)
            if isPrime(n)==1 :
                primeCrossNum += 1    

        acc += 2

        totalCrossNum += 4        

    print primeCrossNum,"/",totalCrossNum, "squareNum : ",squareNum
    if 100*primeCrossNum/totalCrossNum < 10 and not squareNum==1:
        break
