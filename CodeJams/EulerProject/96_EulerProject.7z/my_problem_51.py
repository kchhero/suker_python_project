import math
import sys

def suker_isPrimeNum(n) :
    if n==2 or n==3 or n==5 or n==7 :
        return 1
    elif n%2==0 :
        return 0
    else :
        sqrtNum = int(math.sqrt(n))
        for i in range(3,sqrtNum+1) :
            if n%i==0 :
                return 0

        return 1

startNum = 10000001
endNum =   20000001
digitCnt = 8

primeL = [i for i in xrange(startNum,endNum,2) if suker_isPrimeNum(i)==1]
print "prime make done!"

baseNum = 8
for i in range(digitCnt-2) :
    for j in range(i+1,digitCnt-1) :
        for p in xrange(startNum,endNum,2) :
            if suker_isPrimeNum(p)==1 :
                cnt = 0
                tempStrL = []
                pStr = str(p)
                for ll in range(len(pStr)) :
                    tempStrL.append(pStr[ll])               

                for ttt in range(10) :
                    if i==0 and ttt==0 :
                        pass
                    elif ttt>=3 and cnt==0 :#<=(ttt-3) :
                        break
                    else :
                        tempStrL[i] = str(ttt)
                        tempStrL[j] = str(ttt)
                        tempInt = int("".join(tempStrL))
                        
                        if suker_isPrimeNum(tempInt)==1 :
                            cnt += 1
                            #print tempInt,cnt
    
                        if baseNum==cnt :
                            print "Answer :",pStr,i,j
                            sys.exit()
                
            
        
