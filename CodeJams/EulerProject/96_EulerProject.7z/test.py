lll = [11,12,13,14,11,11,20,12]
print lll
lll.remove(11)
print lll
lll.remove(11)
print lll
