import sys,math

setSL = [i**2 for i in range(1,101)]
print "setSL make done!"

def suker_factorial(n) :
    if n==2 :
        return 2
    elif n==1 :
        return 1
    else :
        return n*suker_factorial(n-1)
    
print suker_factorial(100)/(suker_factorial(50)**2)