from distutils.core import setup

setup (name = 'distTT',
       version = '1.0',
       author = 'suker',
       packages = ['distTTIN', 'distTTIN.utils'],
       )
