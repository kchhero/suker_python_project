print("bar")
