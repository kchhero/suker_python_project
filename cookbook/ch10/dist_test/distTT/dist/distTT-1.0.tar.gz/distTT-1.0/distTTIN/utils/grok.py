print("grok")
