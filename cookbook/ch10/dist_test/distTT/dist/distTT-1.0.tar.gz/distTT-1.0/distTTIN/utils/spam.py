print("spam")
